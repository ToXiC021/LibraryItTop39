﻿using static System.Net.Mime.MediaTypeNames;

namespace LibraryLibrary
{
    public class Student
    {
        public int Id { get; set; }
        public string FirstName { get; set; }
        public string SecondName { get; set; }
        public string LastName { get; set; }
        public int GroupId { get; set; }
        public string Email { get; set; }
        public string PhoneNumber { get; set; }
        public int StudentCartNumber { get; set; }
        public byte[] Photo { get; set; }
    }
    public class Book
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Author { get; set; }
        public string ISBN { get; set; }
        public string Publication { get; set; }
        public DateOnly PublicationYear { get; set; }
        public byte[] Barcode { get; set; }
        public byte[] Cover { get; set; }
    }
    public class Group
    {
        public int Id { get; set; }
        public string Name { get; set; }
    }
    public class Abonement
    {
        public int Id { get; set; }
        public int StudentId { get; set; }
        public int BookId { get; set; }
        public DateOnly StartAbonementDate {  get; set; }
        public DateOnly EndAbonementDate { get; set; }
        public bool IsStudentReturnBook { get; set; }
    }
}
